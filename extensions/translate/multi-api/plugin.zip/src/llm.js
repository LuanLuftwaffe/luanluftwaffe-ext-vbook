var LLM_NAME = "Universal AI";
var LLM_DEFAULT_ENDPOINT = "https://api.deepseek.com/chat/completions";
var LLM_DEPLOY_ENDPOINT = "https://api-cdn.deploy.com/api/v1/chat/completions";
var LLM_DEFAULT_MODEL = "deepseek-flash";
var LLM_ROTATE_KEY_STATUSES = { 401: true, 402: true, 403: true, 405: true, 408: true, 429: true, 500: true, 502: true, 503: true, 504: true, 524: true };

var LLM_MODEL_INFO = {
    // DeepSeek
    "deploy-deepseek-flash": { apiModel: "deepseek-ai/deepseek-v4.1-flash-1017", endpoint: LLM_DEPLOY_ENDPOINT, protocol: "openai", thinking: false, isReasoner: false },
    "deepseek-flash": { apiModel: "deepseek-flash", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: false, isReasoner: false },
    "deepseek-flash-thinking": { apiModel: "deepseek-flash", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: true, isReasoner: true },
    "deepseek-chat": { apiModel: "deepseek-chat", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: null, isReasoner: false },
    "deepseek-reasoner": { apiModel: "deepseek-reasoner", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: null, isReasoner: true },
    "deepseek-v4-pro": { apiModel: "deepseek-v4-pro", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: false, isReasoner: false },
    "deepseek-v4-pro-thinking": { apiModel: "deepseek-v4-pro", endpoint: LLM_DEFAULT_ENDPOINT, protocol: "openai", thinking: true, isReasoner: true },

    // Google Gemini Native (Thế hệ mới nhất 3.x, 4.x & tương thích ngược)
    "gemini-3.1-pro-preview": { apiModel: "gemini-3.1-pro-preview", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.1-pro": { apiModel: "gemini-3.1-pro-preview", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.5-flash-lite": { apiModel: "gemini-3.5-flash-lite", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.6-flash": { apiModel: "gemini-3.6-flash", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.8-flash": { apiModel: "gemini-3.8-flash", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-4-argon": { apiModel: "gemini-4-argon", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3-flash-preview": { apiModel: "gemini-3-flash-preview", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.1-flash-lite": { apiModel: "gemini-3.1-flash-lite", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-2.5-flash": { apiModel: "gemini-2.5-flash", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-2.5-flash-lite": { apiModel: "gemini-2.5-flash-lite", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-2.5-pro": { apiModel: "gemini-2.5-pro", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    // Tự động map các model cũ (2.0, 1.5) đã khai tử sang thế hệ mới để không bị lỗi 404
    "gemini-2.0-flash": { apiModel: "gemini-3.5-flash-lite", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-1.5-flash": { apiModel: "gemini-3.5-flash-lite", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-1.5-pro": { apiModel: "gemini-3.1-pro-preview", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },
    "gemini-3.7-flash": { apiModel: "gemini-3.8-flash", endpoint: "", protocol: "gemini", thinking: null, isReasoner: false },

    // Anthropic Claude Native
    "claude-3-5-sonnet": { apiModel: "claude-3-5-sonnet-20241022", endpoint: "https://api.anthropic.com/v1/messages", protocol: "claude", thinking: null, isReasoner: false },
    "claude-3-5-sonnet-20241022": { apiModel: "claude-3-5-sonnet-20241022", endpoint: "https://api.anthropic.com/v1/messages", protocol: "claude", thinking: null, isReasoner: false },
    "claude-3-5-haiku": { apiModel: "claude-3-5-haiku-20241022", endpoint: "https://api.anthropic.com/v1/messages", protocol: "claude", thinking: null, isReasoner: false },
    "claude-3-5-haiku-20241022": { apiModel: "claude-3-5-haiku-20241022", endpoint: "https://api.anthropic.com/v1/messages", protocol: "claude", thinking: null, isReasoner: false },
    "claude-3-7-sonnet": { apiModel: "claude-3-7-sonnet-20250219", endpoint: "https://api.anthropic.com/v1/messages", protocol: "claude", thinking: null, isReasoner: false },

    // OpenAI
    "gpt-4o-mini": { apiModel: "gpt-4o-mini", endpoint: "https://api.openai.com/v1/chat/completions", protocol: "openai", thinking: null, isReasoner: false },
    "gpt-4o": { apiModel: "gpt-4o", endpoint: "https://api.openai.com/v1/chat/completions", protocol: "openai", thinking: null, isReasoner: false },
    "o1-mini": { apiModel: "o1-mini", endpoint: "https://api.openai.com/v1/chat/completions", protocol: "openai", thinking: null, isReasoner: true },
    "o3-mini": { apiModel: "o3-mini", endpoint: "https://api.openai.com/v1/chat/completions", protocol: "openai", thinking: null, isReasoner: true },

    // Groq
    "groq-llama-3.3-70b": { apiModel: "llama-3.3-70b-versatile", endpoint: "https://api.groq.com/openai/v1/chat/completions", protocol: "openai", thinking: null, isReasoner: false }
};

function llmNormalizeEndpoint(url) {
    if (!url) return "";
    var u = String(url).trim();
    if (!u) return "";
    if (u.indexOf("http://") !== 0 && u.indexOf("https://") !== 0) {
        u = "https://" + u;
    }
    u = u.replace(/\/+$/, "");
    if (u.indexOf("completions") === -1 && u.indexOf(":generateContent") === -1 && u.indexOf("/messages") === -1) {
        u = u + "/chat/completions";
    }
    return u;
}

function llmGetCustomEndpoint() {
    var endpoint = "";
    try {
        if (typeof custom_endpoint !== "undefined" && custom_endpoint) {
            endpoint = String(custom_endpoint).trim();
        }
    } catch (eConst) {}
    if (!endpoint) {
        try {
            endpoint = String(localConfig.getItem("custom_endpoint") || "").trim();
        } catch (e0) {}
    }
    if (!endpoint) {
        try {
            endpoint = String(localStorage.getItem("custom_endpoint") || "").trim();
        } catch (e) {}
    }
    if (!endpoint) {
        try {
            var gen = localStorage.getItem("translation_config_generation");
            if (gen && parseInt(gen, 10) > 0) {
                endpoint = String(localStorage.getItem("g" + gen + "_custom_endpoint") || "").trim();
            }
        } catch (e2) {}
    }
    return endpoint;
}

function llmGetCustomModel() {
    var model = "";
    try {
        if (typeof custom_model !== "undefined" && custom_model) {
            model = String(custom_model).trim();
        }
    } catch (eConst) {}
    if (!model) {
        try {
            model = String(localConfig.getItem("custom_model") || "").trim();
        } catch (e0) {}
    }
    if (!model) {
        try {
            model = String(localStorage.getItem("custom_model") || "").trim();
        } catch (e) {}
    }
    if (!model) {
        try {
            var gen = localStorage.getItem("translation_config_generation");
            if (gen && parseInt(gen, 10) > 0) {
                model = String(localStorage.getItem("g" + gen + "_custom_model") || "").trim();
            }
        } catch (e2) {}
    }
    return model || "deepseek-flash";
}

function llmGetConfiguredProtocol() {
    var proto = "";
    try {
        if (typeof api_protocol !== "undefined" && api_protocol) {
            proto = String(api_protocol).trim().toLowerCase();
        }
    } catch (e0) {}
    if (!proto) {
        try {
            proto = String(localConfig.getItem("api_protocol") || "").trim().toLowerCase();
        } catch (e1) {}
    }
    if (!proto) {
        try {
            proto = String(localStorage.getItem("api_protocol") || "").trim().toLowerCase();
        } catch (e2) {}
    }
    if (!proto) {
        try {
            var gen = localStorage.getItem("translation_config_generation");
            if (gen && parseInt(gen, 10) > 0) {
                proto = String(localStorage.getItem("g" + gen + "_api_protocol") || "").trim().toLowerCase();
            }
        } catch (e3) {}
    }
    return proto || "auto";
}

function llmDetectProtocol(selectedModel, apiModel, currentKey, customEndpoint) {
    var configured = llmGetConfiguredProtocol();
    if (configured === "openai" || configured === "gemini" || configured === "claude") {
        return configured;
    }

    // 1. Kiểm tra preset model
    if (selectedModel && LLM_MODEL_INFO[selectedModel] && LLM_MODEL_INFO[selectedModel].protocol) {
        return LLM_MODEL_INFO[selectedModel].protocol;
    }

    // 2. Kiểm tra tên model
    var m = String(apiModel || selectedModel || "").toLowerCase();
    if (m.indexOf("gemini") === 0) {
        var epG = String(customEndpoint || "").toLowerCase();
        if (epG.indexOf("completions") !== -1) {
            return "openai";
        }
        return "gemini";
    }
    if (m.indexOf("claude") === 0) {
        var epC = String(customEndpoint || "").toLowerCase();
        if (epC.indexOf("completions") !== -1) {
            return "openai";
        }
        return "claude";
    }

    // 3. Kiểm tra custom endpoint nếu có
    if (customEndpoint && customEndpoint !== LLM_DEFAULT_ENDPOINT) {
        var epCheck = String(customEndpoint).toLowerCase();
        if (epCheck.indexOf("completions") !== -1) {
            return "openai";
        }
        if (epCheck.indexOf("googleapis.com") !== -1 || epCheck.indexOf(":generatecontent") !== -1) {
            return "gemini";
        }
        if (epCheck.indexOf("anthropic.com") !== -1 || epCheck.indexOf("/messages") !== -1) {
            return "claude";
        }
    }

    // 4. Kiểm tra tiền tố API Key
    var k = String(currentKey || "").trim();
    if (k.indexOf("AIzaSy") === 0 || (k.indexOf("AIza") === 0 && k.length > 30)) {
        return "gemini";
    }
    if (k.indexOf("sk-ant-") === 0) {
        return "claude";
    }

    return "openai";
}

function llmResolveEndpoint(protocol, selectedModel, apiModel, customEndpoint) {
    var raw = String(customEndpoint || "").trim();

    // Nếu người dùng cung cấp custom endpoint và không phải endpoint mặc định của DeepSeek
    if (raw && raw !== LLM_DEFAULT_ENDPOINT) {
        if (protocol === "gemini") {
            if (raw.indexOf("{model}") !== -1) {
                return raw.replace(/\{model\}/g, encodeURIComponent(apiModel));
            }
            if (raw.indexOf(":generateContent") !== -1) {
                return raw;
            }
            var cleanUrl = raw.replace(/\/+$/, "");
            return cleanUrl + "/" + encodeURIComponent(apiModel) + ":generateContent";
        } else if (protocol === "claude") {
            if (raw.indexOf("/messages") !== -1) {
                return raw;
            }
            var cleanClaude = raw.replace(/\/+$/, "");
            if (cleanClaude.indexOf("/v1") !== -1) {
                return cleanClaude + "/messages";
            }
            return cleanClaude + "/v1/messages";
        } else {
            return llmNormalizeEndpoint(raw);
        }
    }

    // Nếu chọn Deploy model
    if (selectedModel && LLM_MODEL_INFO[selectedModel] && LLM_MODEL_INFO[selectedModel].endpoint) {
        return LLM_MODEL_INFO[selectedModel].endpoint;
    }

    // Endpoint mặc định theo từng protocol
    if (protocol === "gemini") {
        return "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(apiModel) + ":generateContent";
    }
    if (protocol === "claude") {
        return "https://api.anthropic.com/v1/messages";
    }
    return LLM_DEFAULT_ENDPOINT;
}

function llmGetEndpoint(selectedModel) {
    var customEp = llmGetCustomEndpoint();
    var protocol = llmDetectProtocol(selectedModel, selectedModel, "", customEp);
    return llmResolveEndpoint(protocol, selectedModel, selectedModel, customEp);
}

function llmNormalizeModel(model) {
    var selected = String(model || "").trim();
    if (selected === "deepseek-custom" || selected === "custom") {
        return llmGetCustomModel();
    }
    if (LLM_MODEL_INFO[selected]) {
        return selected;
    }
    return selected || LLM_DEFAULT_MODEL;
}

function llmIsReasonerModel(model) {
    var m = String(model || "").toLowerCase();
    return m === "deepseek-reasoner" || 
           m.indexOf("reasoner") !== -1 || 
           m.indexOf("-r1") !== -1 || 
           m.indexOf("thinking") !== -1 ||
           m.indexOf("o1-") === 0 || 
           m === "o1" || 
           m.indexOf("o3-") === 0 || 
           m === "o3";
}

// Tự động nhận diện nếu key là dạng Deploy Secret Key (mua từ deploy.com)
function llmDetectKeyProvider(key) {
    var k = String(key || "").trim();
    if (!k) return "deepseek";
    if (k.endsWith("==") || (k.indexOf("sk-") !== 0 && k.length < 30)) {
        return "deploy";
    }
    return "deepseek";
}

// options: { temperature, maxTokens, json }
function llmBuildBody(model, systemPrompt, userText, options) {
    options = options || {};
    var selected = String(model || "").trim();
    var apiModel = selected;
    var thinking = null;
    var isReasoner = false;

    if (selected === "deepseek-custom" || selected === "custom") {
        apiModel = llmGetCustomModel();
        isReasoner = llmIsReasonerModel(apiModel);
    } else if (LLM_MODEL_INFO[selected]) {
        var info = LLM_MODEL_INFO[selected];
        apiModel = info.apiModel;
        thinking = info.thinking;
        isReasoner = info.isReasoner;
    } else {
        apiModel = selected || LLM_DEFAULT_MODEL;
        isReasoner = llmIsReasonerModel(apiModel);
    }

    var messages = [];
    if (systemPrompt) {
        messages.push({ role: "system", content: systemPrompt });
    }
    messages.push({ role: "user", content: userText });

    var body = {
        model: apiModel,
        messages: messages,
        max_tokens: options.maxTokens || 8192,
        stream: false,
        _selected: selected,
        _systemPrompt: systemPrompt || "",
        _userText: userText || "",
        _options: options,
        _thinking: thinking,
        _isReasoner: isReasoner
    };

    if (thinking !== null) {
        body.thinking = { type: thinking ? "enabled" : "disabled" };
    }

    if (!isReasoner && thinking !== true && options.temperature !== undefined && options.temperature !== null) {
        body.temperature = Number(options.temperature);
    }

    if (options.json) {
        body.response_format = { type: "json_object" };
    }
    return body;
}

function llmFastHash(str) {
    str = String(str || "");
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash |= 0;
    }
    return Math.abs(hash).toString(36) + "_" + str.length;
}

function llmSleep(ms) {
    if (!ms || ms <= 0) return;
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) {
            if (localStorage.getItem("batch_pacing_delay") === "0") return;
        }
    } catch (e) {}
    var start = Date.now ? Date.now() : new Date().getTime();
    while ((Date.now ? Date.now() : new Date().getTime()) - start < ms) {
        // Rhino sync wait
    }
}

function llmEnforceRequestPacing() {
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) {
            var minDelay = 1500;
            var customDelay = localStorage.getItem("batch_pacing_delay");
            if (customDelay) {
                var parsed = parseInt(customDelay, 10);
                if (!isNaN(parsed) && parsed >= 0) minDelay = parsed;
            }
            if (minDelay > 0) {
                var lastStr = localStorage.getItem("vb_last_request_time");
                if (lastStr) {
                    var lastTime = parseInt(lastStr, 10);
                    var now = Date.now ? Date.now() : new Date().getTime();
                    var elapsed = now - lastTime;
                    if (elapsed >= 0 && elapsed < minDelay) {
                        llmSleep(minDelay - elapsed);
                    }
                }
                var newNow = Date.now ? Date.now() : new Date().getTime();
                localStorage.setItem("vb_last_request_time", String(newNow));
            }
        }
    } catch (e) {}
}

function llmIsKeyDead(key) {
    try {
        if (!key || typeof localStorage === "undefined" || !localStorage || !localStorage.getItem) return false;
        var deadUntil = localStorage.getItem("vb_dead_key_" + llmFastHash(key));
        if (deadUntil) {
            var exp = parseInt(deadUntil, 10);
            var now = Date.now ? Date.now() : new Date().getTime();
            if (now < exp) return true;
        }
    } catch (e) {}
    return false;
}

function llmMarkKeyDead(key, durationMs) {
    try {
        if (!key || typeof localStorage === "undefined" || !localStorage || !localStorage.setItem) return;
        var now = Date.now ? Date.now() : new Date().getTime();
        localStorage.setItem("vb_dead_key_" + llmFastHash(key), String(now + (durationMs || 1800000)));
    } catch (e) {}
}

var _llmKeyPointer = 0;
var LLM_KEY_POINTER_STORAGE_KEY = "vb_llm_key_pointer";

function llmGetNextKeyIndex(keyCount) {
    if (keyCount <= 1) return 0;
    var pointer = _llmKeyPointer;
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.getItem) {
            var saved = localStorage.getItem(LLM_KEY_POINTER_STORAGE_KEY);
            if (saved !== null && saved !== "") {
                var p = parseInt(saved, 10);
                if (!isNaN(p) && p >= 0) {
                    pointer = p;
                }
            }
        }
    } catch (e) {}

    var currentIndex = pointer % keyCount;
    var nextIndex = (currentIndex + 1) % keyCount;
    _llmKeyPointer = nextIndex;
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.setItem) {
            localStorage.setItem(LLM_KEY_POINTER_STORAGE_KEY, String(nextIndex));
        }
    } catch (e2) {}
    return currentIndex;
}

function llmSetKeyPointer(index, keyCount) {
    if (keyCount <= 1) return;
    var next = (index + 1) % keyCount;
    _llmKeyPointer = next;
    try {
        if (typeof localStorage !== "undefined" && localStorage && localStorage.setItem) {
            localStorage.setItem(LLM_KEY_POINTER_STORAGE_KEY, String(next));
        }
    } catch (e) {}
}

// Thử lần lượt từng key trong danh sách với cơ chế Round-Robin cân bằng tải;
// Tự động điều phối theo giao thức: OpenAI Chat Completions, Google Gemini Native, Anthropic Claude Native.
// Trả về { text, finishReason, error, keyIndex }
function llmRequest(apiKeys, body, timeout) {
    if (!apiKeys || apiKeys.length === 0) {
        return { text: "", finishReason: "", error: "Chưa cấu hình API Key cho " + LLM_NAME, keyIndex: -1 };
    }

    llmEnforceRequestPacing();

    var selectedModel = body._selected || body.model;
    var apiModel = body.model;
    var systemPrompt = body._systemPrompt || "";
    var userText = body._userText || "";
    var options = body._options || {};
    var thinking = body._thinking;
    var isReasoner = body._isReasoner;
    var rawCustomEndpoint = llmGetCustomEndpoint();
    var lastError = "";

    // Timeout thông minh theo loại model/giao thức
    var effectiveTimeout = timeout;
    if (!effectiveTimeout) {
        if (isReasoner) {
            effectiveTimeout = 120000;
        } else {
            effectiveTimeout = 75000;
        }
    }

    var startKeyIndex = llmGetNextKeyIndex(apiKeys.length);
    var totalAttempts = apiKeys.length === 1 ? 3 : Math.min(apiKeys.length * 2, 6);

    for (var attempt = 0; attempt < totalAttempts; attempt++) {
        var keyIndex = (startKeyIndex + attempt) % apiKeys.length;
        var currentKey = String(apiKeys[keyIndex] || "").trim();
        if (!currentKey) continue;

        if (apiKeys.length > 1 && llmIsKeyDead(currentKey) && attempt + 1 < totalAttempts) {
            continue;
        }

        var protocol = llmDetectProtocol(selectedModel, apiModel, currentKey, rawCustomEndpoint);
        var endpoint = llmResolveEndpoint(protocol, selectedModel, apiModel, rawCustomEndpoint);

        var headers = {
            "Content-Type": "application/json"
        };
        var payloadObj = {};

        if (protocol === "gemini") {
            headers["x-goog-api-key"] = currentKey;
            payloadObj = {
                contents: [
                    {
                        role: "user",
                        parts: [{ text: userText }]
                    }
                ],
                generationConfig: {
                    maxOutputTokens: options.maxTokens || 8192
                },
                safetySettings: [
                    { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_CIVIC_INTEGRITY", threshold: "BLOCK_NONE" }
                ]
            };
            if (systemPrompt) {
                payloadObj.systemInstruction = {
                    parts: [{ text: systemPrompt }]
                };
            }
            if (!isReasoner && options.temperature !== undefined && options.temperature !== null) {
                payloadObj.generationConfig.temperature = Number(options.temperature);
            }
            if (options.json) {
                payloadObj.generationConfig.responseMimeType = "application/json";
            }
        } else if (protocol === "claude") {
            headers["x-api-key"] = currentKey;
            headers["anthropic-version"] = "2023-06-01";
            payloadObj = {
                model: apiModel,
                max_tokens: options.maxTokens || 8192,
                messages: [
                    { role: "user", content: userText }
                ]
            };
            if (systemPrompt) {
                payloadObj.system = systemPrompt;
            }
            if (!isReasoner && options.temperature !== undefined && options.temperature !== null) {
                payloadObj.temperature = Number(options.temperature);
            }
        } else {
            // OpenAI format
            headers["Authorization"] = "Bearer " + currentKey;

            var keyProvider = llmDetectKeyProvider(currentKey);
            if (keyProvider === "deploy" && endpoint === LLM_DEFAULT_ENDPOINT) {
                endpoint = LLM_DEPLOY_ENDPOINT;
                if (!selectedModel || selectedModel === "deepseek-flash" || selectedModel === "deploy-deepseek-flash") {
                    apiModel = "deepseek-ai/deepseek-v4.1-flash-1017";
                }
            }

            var messages = [];
            if (systemPrompt) {
                messages.push({ role: "system", content: systemPrompt });
            }
            messages.push({ role: "user", content: userText });

            payloadObj = {
                model: apiModel,
                messages: messages,
                max_tokens: options.maxTokens || 8192,
                stream: false
            };

            if (thinking !== null) {
                payloadObj.thinking = { type: thinking ? "enabled" : "disabled" };
            }

            if (!isReasoner && thinking !== true && options.temperature !== undefined && options.temperature !== null) {
                payloadObj.temperature = Number(options.temperature);
            }

            if (options.json) {
                payloadObj.response_format = { type: "json_object" };
            }
        }

        var payload = JSON.stringify(payloadObj);
        var response;
        try {
            response = fetch(endpoint, {
                method: "POST",
                headers: headers,
                body: payload,
                timeout: effectiveTimeout
            });
        } catch (e) {
            lastError = LLM_NAME + " Lỗi mạng (" + endpoint + "): " + String(e);
            llmSetKeyPointer(keyIndex, apiKeys.length);
            if (attempt + 1 < totalAttempts) {
                llmSleep(2000);
            }
            continue;
        }

        if (!response || !response.ok) {
            var status = response ? response.status : 0;
            lastError = llmApiError(response, protocol);

            if (status === 401 || status === 402) {
                llmMarkKeyDead(currentKey, 3600000);
            }

            if (LLM_ROTATE_KEY_STATUSES[status]) {
                llmSetKeyPointer(keyIndex, apiKeys.length);
                if (attempt + 1 < totalAttempts) {
                    var backoff = (status === 504 || status === 429) ? ((attempt + 1) * 2000) : 1000;
                    llmSleep(backoff);
                }
                continue;
            }
            return { text: "", finishReason: "", error: lastError, keyIndex: keyIndex };
        }

        var data = null;
        try {
            if (typeof response.json === "function") {
                data = response.json();
            }
        } catch (eJson) {}
        if (!data || typeof data !== "object") {
            try {
                if (typeof response.text === "function") {
                    data = JSON.parse(response.text());
                } else if (typeof response.body === "string") {
                    data = JSON.parse(response.body);
                }
            } catch (e2) {
                if (attempt + 1 < totalAttempts) continue;
                return { text: "", finishReason: "", error: LLM_NAME + " trả về dữ liệu JSON không hợp lệ", keyIndex: keyIndex };
            }
        }

        var content = "";
        var finishReason = "";

        if (protocol === "gemini") {
            var candidate = data && data.candidates && data.candidates.length > 0 ? data.candidates[0] : null;
            if (candidate && candidate.content && candidate.content.parts) {
                for (var p = 0; p < candidate.content.parts.length; p++) {
                    if (candidate.content.parts[p] && candidate.content.parts[p].text) {
                        content += String(candidate.content.parts[p].text);
                    }
                }
            }
            finishReason = candidate && candidate.finishReason ? String(candidate.finishReason) : "";
            if (!content && finishReason && finishReason !== "STOP") {
                lastError = "Gemini dừng với lý do: " + finishReason;
                if (attempt + 1 < totalAttempts) continue;
                return { text: "", finishReason: finishReason, error: lastError, keyIndex: keyIndex };
            }
        } else if (protocol === "claude") {
            if (data && data.content && Array.isArray(data.content)) {
                for (var c = 0; c < data.content.length; c++) {
                    var block = data.content[c];
                    if (block && block.type === "text" && block.text) {
                        content += String(block.text);
                    }
                }
            }
            finishReason = data && data.stop_reason ? String(data.stop_reason) : "";
        } else {
            // OpenAI
            var choice = data && data.choices && data.choices.length > 0 ? data.choices[0] : null;
            var message = choice && choice.message ? choice.message : null;
            content = message && message.content ? String(message.content) : "";
            finishReason = choice && choice.finish_reason ? String(choice.finish_reason) : "";
        }

        llmSetKeyPointer(keyIndex, apiKeys.length);

        return {
            text: content,
            finishReason: finishReason,
            error: "",
            keyIndex: keyIndex
        };
    }

    return {
        text: "",
        finishReason: "",
        error: lastError || "Tất cả API Key của " + LLM_NAME + " đều không khả dụng hoặc máy chủ phản hồi quá lâu (504)",
        keyIndex: -1
    };
}

function llmApiError(response, protocol) {
    if (!response) return LLM_NAME + " Không có phản hồi từ máy chủ";
    var message = "";
    try {
        var text = typeof response.text === "function" ? response.text() : "";
        if (text) {
            var data = JSON.parse(text);
            if (data) {
                if (data.error) {
                    if (typeof data.error === "string") {
                        message = data.error;
                    } else if (data.error.message) {
                        message = String(data.error.message);
                    }
                } else if (data.promptFeedback && data.promptFeedback.blockReason) {
                    message = "Prompt bị chặn: " + data.promptFeedback.blockReason;
                }
            }
        }
    } catch (e) {}

    var statusDesc = "";
    if (response.status === 401) statusDesc = " (Sai API Key hoặc Endpoint)";
    else if (response.status === 402) statusDesc = " (Tài khoản hết số dư / Insufficient Balance)";
    else if (response.status === 403) statusDesc = " (Bị từ chối truy cập / Forbidden)";
    else if (response.status === 405) statusDesc = " (Phương thức không hợp lệ hoặc Key bị tạm dừng)";
    else if (response.status === 429) statusDesc = " (Quá tải yêu cầu / Rate Limit)";
    else if (response.status === 400) statusDesc = " (Yêu cầu không hợp lệ / Bad Request)";
    else if (response.status === 504) statusDesc = " (Máy chủ phản hồi quá lâu / Gateway Timeout)";
    else if (response.status === 500 || response.status === 502 || response.status === 503) statusDesc = " (Máy chủ đang bận / Service Unavailable)";

    var prefix = protocol ? "[" + protocol.toUpperCase() + "] " : "";
    return prefix + LLM_NAME + " HTTP " + response.status + statusDesc + (message ? ": " + message : "");
}
