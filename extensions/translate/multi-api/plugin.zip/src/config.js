load('prompts.js');
load('llm.js');

function execute() {
    var config = {};

    // ==========================================
    // LỚP 1 — THIẾT LẬP NHANH (CHO PHẦN LỚN NGƯỜI ĐỌC)
    // ==========================================
    config[translationConfigKey("translation_mode")] = {
        title: "⚡ Chế độ dịch (Speed & Quality)",
        subtitle: "Nhanh (siêu tốc ~15s, ít token) | Cân bằng (mặc định) | Chất lượng cao (trau chuốt)",
        default: "balanced",
        values: ["balanced", "fast", "quality"],
        mode: "select"
    };

    config[translationConfigKey("default_style")] = {
        title: "🎭 Phong cách dịch mặc định",
        subtitle: "Viết Lại Convert (khuyên dùng cho convert) | Huyền huyễn (tu tiên) | Tự nhiên",
        default: "viet-lai-convert",
        values: ["viet-lai-convert", "huyen-huyen", "tu-nhien", "kiem-hiep", "khoa-huyen", "do-thi", "linh-di", "he-thong"],
        mode: "select"
    };

    config[translationConfigKey("api_key")] = {
        title: "🔑 API Keys (Gemini / DeepSeek / Claude / Bên thứ 3)",
        subtitle: "Hỗ trợ key Google Gemini (AI Studio), DeepSeek, Anthropic Claude, Groq, OpenRouter, đại lý mua API bên thứ 3... Mỗi dòng 1 key, tự chuyển khi lỗi/hết quota",
        default: "",
        mode: "list",
        format: "text"
    };

    config[translationConfigKey("use_translation_cache")] = {
        title: "💾 Bộ nhớ đệm (Cache chương)",
        subtitle: "Lưu tạm bản dịch chương; khi lướt đọc lại sẽ nạp tức thì 0ms mà không tốn token",
        default: "true",
        mode: "toggle"
    };

    // ==========================================
    // LỚP 2 — TÙY CHỈNH NÂNG CAO
    // ==========================================
    config[translationConfigKey("api_protocol")] = {
        title: "🔌 Giao thức API (Protocol)",
        subtitle: "auto (Tự nhận diện) | openai (OpenAI / DeepSeek / Groq / OpenRouter) | gemini (Google Gemini Native) | claude (Anthropic Claude Native)",
        default: "auto",
        values: ["auto", "openai", "gemini", "claude"],
        mode: "select"
    };

    config[translationConfigKey("custom_model")] = {
        title: "🤖 Tên Model tùy chỉnh",
        subtitle: "Áp dụng khi chọn 'Model Tùy Chỉnh (Custom)' (ví dụ: gemini-3.1-pro-preview, gemini-3.5-flash-lite, claude-3-5-sonnet-20241022, deepseek-chat, gpt-4o, llama-3.3-70b-versatile, qwen2.5:72b...)",
        default: "deepseek-chat",
        mode: "input",
        format: "text"
    };

    config[translationConfigKey("custom_endpoint")] = {
        title: "🌐 Endpoint tùy chỉnh (Khi mua API bên thứ 3 / Proxy)",
        subtitle: "Để trống nếu dùng API chính hãng (Google, DeepSeek, Claude...). Chỉ điền khi mua API qua bên thứ 3 (OpenRouter, SiliconFlow, Together AI...), chạy server riêng hoặc proxy",
        default: "",
        mode: "input",
        format: "text"
    };

    config[translationConfigKey("temperature")] = {
        title: "🌡️ Temperature (Độ sáng tạo)",
        subtitle: "0.0 - 2.0; mặc định 0.3. Tự động bỏ qua khi dùng Reasoner / Thinking model để tránh lỗi HTTP 400",
        default: "0.3",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("max_output_tokens")] = {
        title: "📏 Số token đầu ra tối đa",
        subtitle: "Độ dài văn bản trả về tối đa (khuyên dùng: 8192 token để tối ưu tốc độ & tránh lỗi 504 khi dịch nhiều)",
        default: "8192",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("batch_anti_stop")] = {
        title: "🛡️ Chống dừng khi treo máy tải hàng loạt (Anti-Stop)",
        subtitle: "Khi treo tải 50/100/cả truyện: tự động điều hòa nhịp thở và fallback để tiến trình KHÔNG BAO GIỜ bị dừng giữa chừng",
        default: "true",
        mode: "toggle"
    };

    config[translationConfigKey("batch_pacing_delay")] = {
        title: "⏱️ Độ trễ điều hòa nhịp thở (ms)",
        subtitle: "Khoảng nghỉ giữa các chương khi tải hàng loạt để chống nghẽn TPM/RPM (mặc định: 1500ms)",
        default: "1500",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("use_loc_name")] = {
        title: "📖 Sử dụng lọc Name Hán-Việt",
        subtitle: "Tự động trích xuất và áp dụng tên nhân vật, địa danh từ truyện để dịch mượt mà",
        default: "true",
        mode: "toggle"
    };

    config[translationConfigKey("use_vb_basic_dic")] = {
        title: "📚 Sử dụng từ điển cơ bản (vb_basic_dic)",
        subtitle: "Sử dụng từ điển từ khóa Hán-Việt chung tích hợp trong bộ nhớ vBook",
        default: "true",
        mode: "toggle"
    };

    config[translationConfigKey("retry_untranslated_chinese")] = {
        title: "🛠️ Tự sửa phần tiếng Trung còn sót",
        subtitle: "Chỉ kích hoạt khi còn sót từ 5 chữ Hán trở lên (tự tắt ở chế độ Nhanh để tăng tốc)",
        default: "false",
        mode: "toggle"
    };

    config[translationConfigKey("translate_table_of_content")] = {
        title: "📑 Dùng AI dịch mục lục",
        subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; ngôn ngữ Baidu không hỗ trợ sẽ dùng AI để tiết kiệm token",
        default: "false",
        mode: "toggle"
    };

    config[translationConfigKey("translate_detail")] = {
        title: "ℹ️ Dùng AI dịch chi tiết truyện",
        subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; tiết kiệm token",
        default: "false",
        mode: "toggle"
    };

    config[translationConfigKey("translate_discovery")] = {
        title: "🧭 Dùng AI dịch khám phá",
        subtitle: "Tắt: dùng QT (Trung → Việt), sau đó Baidu; tiết kiệm token",
        default: "false",
        mode: "toggle"
    };

    config[translationConfigKey("use_qt_fallback")] = {
        title: "Ưu tiên QT khi dịch bổ sung",
        subtitle: "Chỉ áp dụng cho nội dung tiếng Trung sang tiếng Việt; nếu tắt hoặc QT không dùng được sẽ chuyển sang Baidu",
        default: "true",
        mode: "toggle"
    };

    // ==========================================
    // LỚP 3 — CHUYÊN SÂU & THEO TRUYỆN
    // ==========================================
    config[translationConfigKey("minname")] = {
        title: "⚙️ [Nâng cao] Độ dài tên tối thiểu",
        subtitle: "Số ký tự tối thiểu để nhận diện là tên riêng (mặc định: 2)",
        default: "2",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("maxname")] = {
        title: "⚙️ [Nâng cao] Độ dài tên tối đa",
        subtitle: "Số ký tự tối đa để nhận diện là tên riêng (mặc định: 5)",
        default: "5",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("repeatname")] = {
        title: "⚙️ [Nâng cao] Tần suất xuất hiện tối thiểu để lọc tên",
        subtitle: "Số lần lặp lại trong văn bản để được coi là tên riêng (mặc định: 2)",
        default: "2",
        mode: "input",
        format: "number"
    };

    config[translationConfigKey("system_prompt")] = {
        title: "📝 [Chuyên sâu] Prompt hệ thống dịch thuật",
        subtitle: "Có thể sửa toàn bộ hướng dẫn; giữ các biến {source_language}, {target_language}, {style_prompt}, {source_prompt}, {custom_instruction} và {memory_prompt}",
        default: translationDefaultSystemPrompt(),
        mode: "input",
        format: "text"
    };

    config.translation_prompts = {
        title: "🎭 [Database] Prompt phong cách dịch truyện",
        subtitle: "Dùng chung cho mọi truyện; tự do tạo thêm hoặc sửa đổi các phong cách dịch",
        mode: "database"
    };

    config[translationConfigKey("use_translation_memory")] = {
        title: "🧠 Sử dụng bộ nhớ dịch theo truyện",
        subtitle: "Áp dụng tên riêng, địa danh, thuật ngữ và quan hệ đã lưu cho truyện hiện tại",
        default: "true",
        mode: "toggle"
    };

    config[translationConfigKey("auto_translation_memory")] = {
        title: "Tự động học bộ nhớ dịch sau mỗi chương",
        subtitle: "Chạy thêm 1 lượt AI trích xuất thực thể mới; khuyến nghị tắt để tốc độ đọc nhanh nhất",
        default: "false",
        mode: "toggle"
    };

    config[translationConfigKey("memory_analysis_chapters")] = {
        title: "Số chương phân tích",
        subtitle: "Action 'Phân tích tên và quan hệ' sẽ đọc từ chương đang đọc và các chương kế sau",
        default: "5",
        mode: "input",
        format: "number"
    };

    initializeTranslationPrompts();

    var bookInfo = null;
    try {
        bookInfo = localBook.getInfo();
    } catch (e) {}

    if (bookInfo && bookInfo.id) {
        var bookPromptKey = translationConfigKey(translationBookPromptConfigKey(String(bookInfo.id)));
        config[bookPromptKey] = {
            title: "📌 Yêu cầu dịch riêng cho truyện này",
            subtitle: "Chỉ áp dụng cho cuốn truyện hiện tại, ví dụ: giữ cách xưng hô theo phong cách kiếm hiệp",
            default: "",
            mode: "input",
            format: "text"
        };
        config.translation_memory = {
            title: "📚 [Database] Bộ nhớ dịch của truyện này",
            subtitle: "Tên riêng, địa danh, thuật ngữ và quan hệ đã ghi nhớ; có thể xem, thêm, sửa hoặc xóa",
            mode: "database"
        };
    }

    return Response.success(config);
}

function initializeTranslationPrompts() {
    try {
        var defaults = translationDefaultPrompts();
        var rows = [];
        var total = localDatabase.count(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE);
        if (total === 0) {
            for (var style in defaults) {
                if (!defaults.hasOwnProperty(style)) continue;
                rows.push({ key: style, value: defaults[style] });
            }
        } else {
            var storedPrompts = {};
            var storedRows = localDatabase.list(
                TRANSLATION_PROMPT_SCOPE,
                TRANSLATION_PROMPT_TABLE,
                0,
                total
            );
            for (var rowIndex = 0; storedRows && rowIndex < storedRows.length; rowIndex++) {
                storedPrompts[String(storedRows[rowIndex].key || "")] = String(storedRows[rowIndex].value || "");
            }
            var definitions = translationDefaultStyleDefinitions();
            for (var index = 0; index < definitions.length; index++) {
                var definition = definitions[index];
                var stored = storedPrompts[definition.id];
                if (stored === translationLegacyPrompt(definition.rule) ||
                    (definition.id === "tu-nhien" && stored === undefined)) {
                    rows.push({ key: definition.id, value: definition.rule });
                }
            }
        }
        if (rows.length > 0) localDatabase.upsertAll(TRANSLATION_PROMPT_SCOPE, TRANSLATION_PROMPT_TABLE, rows);
    } catch (e) {}
}
