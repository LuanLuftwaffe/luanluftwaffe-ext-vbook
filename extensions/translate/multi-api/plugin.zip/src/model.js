function execute() {
    return Response.success([
        {
            id: "deepseek-chat",
            name: "DeepSeek V3 (Chat) [Mượt mà, tự nhiên]",
            description: "DeepSeek V3 chuẩn hóa; văn phong thuần Việt, dịch truyện hàng đầu",
            isNetworkRequired: true
        },
        {
            id: "deepseek-reasoner",
            name: "DeepSeek R1 (Reasoner) [Suy luận sâu]",
            description: "DeepSeek R1 suy nghĩ trước khi dịch; chuyên trị tu tiên, cổ phong, câu khó",
            isNetworkRequired: true
        },
        {
            id: "deepseek-flash",
            name: "DeepSeek V4.1 Flash [Nhanh & Rẻ]",
            description: "DeepSeek V4.1 Flash không suy nghĩ; tốc độ cực nhanh, giá siêu rẻ cho khối lượng dịch lớn",
            isNetworkRequired: true
        },
        {
            id: "deploy-deepseek-flash",
            name: "Deploy - DeepSeek 4.1 Flash [Key Deploy.com]",
            description: "Dành riêng cho key mua từ deploy.com; tự động dùng endpoint Deploy và model deepseek-v4.1-flash-1017",
            isNetworkRequired: true
        },
        {
            id: "deepseek-flash-thinking",
            name: "DeepSeek V4.1 Flash (Thinking) [Có suy nghĩ]",
            description: "DeepSeek V4.1 Flash có suy nghĩ trước khi dịch; dịch kỹ và chuẩn ngữ cảnh hơn",
            isNetworkRequired: true
        },
        {
            id: "gemini-3.1-pro-preview",
            name: "Gemini 3.1 Pro Preview [Google - Flagship cao cấp]",
            description: "Bản Pro chất lượng dịch văn học cao nhất của Google; cần tài khoản có quota Pro",
            isNetworkRequired: true
        },
        {
            id: "gemini-3.5-flash-lite",
            name: "Gemini 3.5 Flash-Lite [Google - Siêu nhanh & Tiết kiệm]",
            description: "Model chuẩn Google AI Studio; cực nhanh, tiết kiệm nhất cho khối lượng dịch lớn",
            isNetworkRequired: true
        },
        {
            id: "gemini-3.6-flash",
            name: "Gemini 3.6 Flash [Google - Cân bằng & Mượt mà]",
            description: "Cân bằng hoàn hảo giữa tốc độ, độ mượt văn học và chi phí",
            isNetworkRequired: true
        },
        {
            id: "gemini-3.8-flash",
            name: "Gemini 3.8 Flash [Google - Flash thông minh nhất]",
            description: "Flash thông minh nhất của Google, dịch kỹ và chuẩn ngữ cảnh hơn",
            isNetworkRequired: true
        },
        {
            id: "gemini-4-argon",
            name: "Gemini 4 Argon [Google - Siêu mô hình thế hệ mới]",
            description: "Model mạnh nhất của Google; tư duy ngữ cảnh sâu rộng",
            isNetworkRequired: true
        },
        {
            id: "gemini-2.5-flash",
            name: "Gemini 2.5 Flash [Google - Bản cũ]",
            description: "Chỉ dùng được với tài khoản còn quyền truy cập Gemini 2.5",
            isNetworkRequired: true
        },
        {
            id: "claude-3-5-sonnet",
            name: "Anthropic Claude 3.5 Sonnet [Native - Văn học xuất sắc]",
            description: "Claude 3.5 Sonnet Messages API native; độ mượt văn học đỉnh cao",
            isNetworkRequired: true
        },
        {
            id: "claude-3-5-haiku",
            name: "Anthropic Claude 3.5 Haiku [Native - Nhanh & Rẻ]",
            description: "Claude 3.5 Haiku; tốc độ cao, tiết kiệm chi phí",
            isNetworkRequired: true
        },
        {
            id: "gpt-4o-mini",
            name: "OpenAI GPT-4o Mini [Tiết kiệm]",
            description: "Model nhỏ gọn, nhanh và tiết kiệm từ OpenAI",
            isNetworkRequired: true
        },
        {
            id: "gpt-4o",
            name: "OpenAI GPT-4o [Toàn diện & Mạnh mẽ]",
            description: "Model flagship đa nhiệm toàn diện của OpenAI",
            isNetworkRequired: true
        },
        {
            id: "groq-llama-3.3-70b",
            name: "Groq - Llama 3.3 70B [Cực nhanh]",
            description: "Llama 3.3 70B chạy trên chip LPU siêu tốc của Groq (dùng key Groq)",
            isNetworkRequired: true
        },
        {
            id: "deepseek-custom",
            name: "🌟 Model Tùy Chỉnh (Custom Model)",
            description: "Dùng tên model, giao thức (OpenAI/Gemini/Claude) và endpoint bạn tự nhập trong Cài đặt",
            isNetworkRequired: true
        }
    ]);
}
